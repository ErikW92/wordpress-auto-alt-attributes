# Wordpress: Add ALT-Attributes automatic to your IMGs
A small plugin for Wordpress that automatically generates missing ALT attributes from the file name. Important for accessibility.

Installation:
1. Navigate to “Plugins” in your Wordpress backend
2. Select “Upload plugin”
3. Upload the auto-alt.zip
4. Activate the plugin

Done :)
